#include "resources.h"

#include "utils.h"


Resources::Resources()
{
    // TODO - init des shaders
}

